plugins {
    id("com.android.application")
}

android {
    namespace = "com.guangcheng.hellangels"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.guangcheng.hellangels"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    androidResources {
        noCompress += listOf("mp3", "wav")
    }
}
