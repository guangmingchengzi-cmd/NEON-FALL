package com.guangcheng.hellangels;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import java.util.Random;

public class GameView extends View {

    // states
    private static final int MENU = 0, PLAYING = 1, PAUSED = 2, RESULT = 3,
            PICK = 4, CARDRES = 5, ENEMY = 6, BEND = 7, CALIB = 8;
    private static final int FREE = 0, BATTLE = 1;
    private static final int LANES = 4;
    private static final long PREROLL = 1800;
    private static final int W_PERFECT = 45, W_GREAT = 90, W_GOOD = 130;

    private static final int CYAN = 0xFF22D3EE, MAGENTA = 0xFFE040FB, ORANGE = 0xFFFFA726,
            PINK = 0xFFFF2E93, GREEN = 0xFF39FF88, RED = 0xFFFF3B4E;
    private static final int[] LANE_COLORS = {ORANGE, CYAN, 0xFFB3E5FC, MAGENTA};
    private static final int C_PERFECT = 0xFFFFE066, C_GREAT = 0xFF66FFB2,
            C_GOOD = 0xFF66B2FF, C_MISS = 0xFFFF5555;

    // ---- battle config (改这些数字就能调平衡) ----
    private static final int DRAW_COUNT = 5;      // 每回合抽几张
    private static final int PICK_COUNT = 3;      // 必须选几张
    private static final int PLAYER_MAX_HP = 100;
    private static final int ENEMY_MAX_HP = 300;
    private static final int OFFENSE_LV = 30, DEFENSE_LV = 25;
    private static final float COIN_HEADS_RATIO = 0.6f;  // 这一段命中率>=60%算正面
    private static final float COIN_CRIT_RATIO = 0.95f;  // >=95%算暴击(硬币威力x1.5)
    private static final float[] RESIST = {1.5f, 1.0f, 0.75f}; // 斩 刺 打 对敌人的倍率
    private static final String[] RESIST_NAME = {"弱点", "普通", "抗性"};
    private static final String[] TYPE_NAME = {"斩", "刺", "打"};
    private static final int[] TYPE_COLOR = {ORANGE, CYAN, MAGENTA};

    private static class Card {
        final String name;
        final int type, base, coinPower, coins, startSec, lenSec;

        Card(String name, int type, int base, int coinPower, int coins, int startSec, int lenSec) {
            this.name = name;
            this.type = type;
            this.base = base;
            this.coinPower = coinPower;
            this.coins = coins;
            this.startSec = startSec;
            this.lenSec = lenSec;
        }
    }

    // 每张卡的"四阶下落谱面"取自这首歌的不同片段
    private static final Card[] POOL = {
            new Card("斩击", 0, 8, 6, 2, 3, 8),
            new Card("突刺", 1, 6, 5, 3, 14, 10),
            new Card("重击", 2, 10, 8, 2, 26, 8),
            new Card("连斩", 0, 4, 4, 4, 36, 12),
            new Card("贯穿", 1, 8, 6, 3, 50, 10),
            new Card("碎骨", 2, 7, 7, 3, 62, 10),
            new Card("乱舞", 0, 5, 5, 4, 74, 12),
            new Card("终结", 2, 6, 8, 4, 88, 14),
    };

    private static class Note {
        long t;
        int lane;
        int coin;
        float w;
        boolean done;
    }

    private final ArrayList<Note> chart = new ArrayList<Note>();   // 完整谱面
    private final ArrayList<Note> notes = new ArrayList<Note>();   // 当前这一局/这张卡的谱面
    private int head = 0;

    private int state = MENU, mode = FREE;
    private MediaPlayer mp, resultMp;
    private SoundPool pool;
    private int hitId;
    private SharedPreferences prefs;
    private final Random rng = new Random();

    private int offsetMs, speedLevel, best;
    private long baseMs = 0, sessionLen = 1;

    // timing
    private boolean musicStarted, songEnded;
    private long startWall, pauseWall, lastWall, lastSong, songNow, stateWall;
    private int lastPos;

    // stats (自由模式)
    private int combo, maxCombo, cPerfect, cGreat, cGood, cMiss;
    private float scoreSum;
    private boolean newBest;

    // battle
    private int playerHp, enemyHp, turn, playIdx, curCoins, turnMiss, enemyDmg;
    private final int[] hand = new int[DRAW_COUNT];
    private final ArrayList<Integer> picked = new ArrayList<Integer>();
    private Card curCard;
    private int lastCardDmg;
    private int[] lastCoinStates = new int[0];
    private boolean win;

    // feedback
    private String judgeText = "", judgeSub = "";
    private long judgeTime;
    private int judgeColor;
    private final long[] fxTime = new long[LANES];
    private final int[] fxColor = new int[LANES];
    private final int[] held = new int[LANES];
    private final int[] ptrLane = new int[32];

    // layout
    private float W, H, laneW, lineY, noteH, dp;
    private final RectF startBtn = new RectF(), battleBtn = new RectF(),
            calBtn = new RectF(), calMinus = new RectF(), calPlus = new RectF(),
            calApply = new RectF(), calReset = new RectF(), calDone = new RectF(),
            spdMinus = new RectF(), spdPlus = new RectF(), pauseBtn = new RectF(),
            resumeBtn = new RectF(), restartBtn = new RectF(), quitBtn = new RectF(),
            againBtn = new RectF(), menuBtn = new RectF(), atkBtn = new RectF();
    private final RectF[] cardRects = new RectF[DRAW_COUNT];

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint = new Paint();
    private final Paint glowPaint = new Paint();
    private final Paint bmpPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final RectF tmp = new RectF();
    private final Path path = new Path();
    private final Path clip = new Path();

    // 场景
    private float sceneTop, sceneBot, hwTop, padTop, padBot, topScale = 0.42f;
    private final RectF heroBox = new RectF(), bossBox = new RectF();
    private float[] px, py, pv, ps;
    private Bitmap heroBmp, bossBmp;       // 可选素材: assets/hero.png assets/boss.png
    private boolean heroCut, bossCut;      // 是否是透明底抠图
    private long bossHitTime;

    // 校准
    private static final int CAL_BEAT = 500;   // 节拍器 120 BPM
    private static final int CAL_WARMUP = 3, CAL_KEEP = 16;
    private MediaPlayer calMp;
    private int calLastPos;
    private long calLastWall, calLastD;
    private int calTaps;
    private boolean calHasD;
    private final ArrayList<Integer> calSamples = new ArrayList<Integer>();

    public GameView(Context context) {
        super(context);
        dp = context.getResources().getDisplayMetrics().density;
        prefs = context.getSharedPreferences("hell_angels", Context.MODE_PRIVATE);
        offsetMs = prefs.getInt("offset", 0);
        speedLevel = prefs.getInt("speed", 6);
        best = prefs.getInt("best", 0);
        Arrays.fill(ptrLane, -1);
        for (int i = 0; i < DRAW_COUNT; i++) cardRects[i] = new RectF();
        p.setTypeface(Typeface.DEFAULT_BOLD);
        loadChart();
        initSound();
        heroBmp = loadBmp("hero.png");
        bossBmp = loadBmp("boss.png");
        heroCut = heroBmp != null && isCutout(heroBmp);
        bossCut = bossBmp != null && isCutout(bossBmp);
        setKeepScreenOn(true);
    }

    private Bitmap loadBmp(String name) {
        try {
            InputStream in = getContext().getAssets().open(name);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > 1200) sample *= 2;
            in = getContext().getAssets().open(name);
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap b = BitmapFactory.decodeStream(in, null, o2);
            in.close();
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    /** 四个角都是透明 -> 当作抠图立绘 */
    private boolean isCutout(Bitmap b) {
        int w = b.getWidth() - 1, h = b.getHeight() - 1;
        return Color.alpha(b.getPixel(0, 0)) < 16 && Color.alpha(b.getPixel(w, 0)) < 16
                && Color.alpha(b.getPixel(0, h)) < 16 && Color.alpha(b.getPixel(w, h)) < 16;
    }

    // ---------------------------------------------------------------- setup

    private void loadChart() {
        try {
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(getContext().getAssets().open("chart.txt"), "UTF-8"));
            String s;
            while ((s = br.readLine()) != null) {
                s = s.trim();
                if (s.length() == 0) continue;
                String[] a = s.split(",");
                Note n = new Note();
                n.t = Long.parseLong(a[0].trim());
                n.lane = Integer.parseInt(a[1].trim());
                chart.add(n);
            }
            br.close();
        } catch (Exception e) {
            Toast.makeText(getContext(), "谱面读取失败: " + e, Toast.LENGTH_LONG).show();
        }
        Collections.sort(chart, new Comparator<Note>() {
            @Override
            public int compare(Note a, Note b) {
                return Long.compare(a.t, b.t);
            }
        });
    }

    private void initSound() {
        try {
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            pool = new SoundPool.Builder().setMaxStreams(8).setAudioAttributes(aa).build();
            AssetFileDescriptor afd = getContext().getAssets().openFd("hit.wav");
            hitId = pool.load(afd, 1);
            afd.close();
        } catch (Exception e) {
            Toast.makeText(getContext(), "打击音效加载失败: " + e, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        W = w;
        H = h;
        laneW = W / LANES;
        sceneTop = H * 0.11f;
        sceneBot = H * 0.49f;
        hwTop = H * 0.52f;
        lineY = H * 0.835f;
        padTop = H * 0.85f;
        padBot = H * 0.94f;
        noteH = H * 0.03f;
        bgPaint.setShader(new LinearGradient(0, 0, 0, H, new int[]{0xFF020816, 0xFF06214A,
                0xFF030B1E}, new float[]{0f, 0.38f, 1f}, Shader.TileMode.CLAMP));
        glowPaint.setShader(new RadialGradient(W / 2f, H * 0.27f, W * 0.75f,
                0x99138CFF, 0x00000000, Shader.TileMode.CLAMP));
        heroBox.set(W * 0.01f, sceneBot - H * 0.36f, W * 0.47f, sceneBot);
        bossBox.set(W * 0.55f, sceneBot - H * 0.36f, W * 0.99f, sceneBot);

        Random r = new Random(5);
        px = new float[26];
        py = new float[26];
        pv = new float[26];
        ps = new float[26];
        for (int i = 0; i < px.length; i++) {
            px[i] = r.nextFloat() * W;
            py[i] = r.nextFloat() * H;
            pv[i] = 0.01f + r.nextFloat() * 0.03f;
            ps[i] = (1f + r.nextFloat() * 2f) * dp;
        }

        float cx = W / 2f, bw = W * 0.62f, bh = H * 0.075f, sq = H * 0.062f;
        startBtn.set(cx - bw / 2, H * 0.48f, cx + bw / 2, H * 0.48f + bh);
        battleBtn.set(cx - bw / 2, H * 0.575f, cx + bw / 2, H * 0.575f + bh);
        float r1 = H * 0.72f, r2 = H * 0.80f;
        calBtn.set(W * 0.10f, r1 - sq / 2, W * 0.90f, r1 + sq / 2);
        calMinus.set(W * 0.08f, H * 0.665f, W * 0.30f, H * 0.665f + bh);
        calPlus.set(W * 0.70f, H * 0.665f, W * 0.92f, H * 0.665f + bh);
        calApply.set(cx - bw * 0.7f, H * 0.765f, cx + bw * 0.7f, H * 0.765f + bh);
        calReset.set(W * 0.08f, H * 0.865f, W * 0.48f, H * 0.865f + bh);
        calDone.set(W * 0.52f, H * 0.865f, W * 0.92f, H * 0.865f + bh);
        spdMinus.set(W * 0.10f, r2 - sq / 2, W * 0.10f + sq, r2 + sq / 2);
        spdPlus.set(W * 0.90f - sq, r2 - sq / 2, W * 0.90f, r2 + sq / 2);

        pauseBtn.set(W * 0.38f, 0, W * 0.62f, H * 0.115f);
        resumeBtn.set(cx - bw / 2, H * 0.38f, cx + bw / 2, H * 0.38f + bh);
        restartBtn.set(cx - bw / 2, H * 0.50f, cx + bw / 2, H * 0.50f + bh);
        quitBtn.set(cx - bw / 2, H * 0.62f, cx + bw / 2, H * 0.62f + bh);
        againBtn.set(cx - bw / 2, H * 0.72f, cx + bw / 2, H * 0.72f + bh);
        menuBtn.set(cx - bw / 2, H * 0.83f, cx + bw / 2, H * 0.83f + bh);
        atkBtn.set(cx - bw / 2, H * 0.84f, cx + bw / 2, H * 0.84f + bh);

        float cw = W * 0.29f, ch = H * 0.19f, gap = W * 0.0325f;
        for (int i = 0; i < 3 && i < DRAW_COUNT; i++) {
            float x = gap + i * (cw + gap), y = H * 0.30f;
            cardRects[i].set(x, y, x + cw, y + ch);
        }
        float x0 = (W - (2 * cw + gap)) / 2f;
        for (int i = 3; i < DRAW_COUNT; i++) {
            float x = x0 + (i - 3) * (cw + gap), y = H * 0.53f;
            cardRects[i].set(x, y, x + cw, y + ch);
        }
    }

    // ---------------------------------------------------------------- session (一局 / 一张卡)

    /** 用完整谱面里 [fromMs,toMs) 的音符建立当前谱面, 时间减去 fromMs */
    private void buildNotes(long fromMs, long toMs, int coins) {
        notes.clear();
        for (Note c : chart) {
            if (c.t < fromMs || c.t >= toMs) continue;
            Note n = new Note();
            n.t = c.t - fromMs;
            n.lane = c.lane;
            notes.add(n);
        }
        int size = notes.size();
        for (int i = 0; i < size; i++) {
            notes.get(i).coin = coins <= 1 ? 0 : Math.min(coins - 1, i * coins / size);
        }
    }

    /** 准备音乐并进入 PLAYING。baseMs 是这一局对应歌曲里的起始位置 */
    private boolean beginSession(long base, long len) {
        releaseMp();
        try {
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            AssetFileDescriptor afd = getContext().getAssets().openFd("music.mp3");
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mp.prepare();
            if (base > 0) mp.seekTo((int) base);
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer m) {
                    songEnded = true;
                }
            });
        } catch (Exception e) {
            Toast.makeText(getContext(), "音乐加载失败: " + e, Toast.LENGTH_LONG).show();
            releaseMp();
            return false;
        }
        baseMs = base;
        sessionLen = Math.max(1, len);
        head = 0;
        combo = maxCombo = cPerfect = cGreat = cGood = cMiss = 0;
        scoreSum = 0;
        newBest = false;
        judgeText = "";
        Arrays.fill(held, 0);
        Arrays.fill(ptrLane, -1);
        Arrays.fill(fxTime, 0);
        songEnded = false;
        musicStarted = false;
        startWall = SystemClock.uptimeMillis();
        lastSong = Long.MIN_VALUE;
        songNow = -PREROLL;
        state = PLAYING;
        return true;
    }

    private void startGame() {
        stopResultSound();
        mode = FREE;
        buildNotes(0, Long.MAX_VALUE, 1);
        int dur = 1;
        try {
            MediaPlayer t = new MediaPlayer();
            AssetFileDescriptor afd = getContext().getAssets().openFd("music.mp3");
            t.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            t.prepare();
            dur = Math.max(1, t.getDuration());
            t.release();
        } catch (Exception ignored) {
        }
        beginSession(0, dur);
    }

    public void pauseGame() {
        if (state == CALIB) {
            toMenu();
            return;
        }
        if (state != PLAYING) return;
        state = PAUSED;
        pauseWall = SystemClock.uptimeMillis();
        if (musicStarted && mp != null) {
            try {
                mp.pause();
            } catch (Exception ignored) {
            }
        }
    }

    private void resumeGame() {
        if (state != PAUSED) return;
        long now = SystemClock.uptimeMillis();
        if (musicStarted && mp != null) {
            try {
                mp.start();
                lastPos = mp.getCurrentPosition();
                lastWall = now;
            } catch (Exception ignored) {
            }
        } else {
            startWall += now - pauseWall;
        }
        state = PLAYING;
    }

    private void finishGame() {
        state = RESULT;
        releaseMp();
        int sc = score();
        if (sc > best) {
            best = sc;
            newBest = true;
            prefs.edit().putInt("best", best).apply();
        }
        playResultSound();
    }

    private void releaseMp() {
        if (mp != null) {
            try {
                mp.stop();
            } catch (Exception ignored) {
            }
            try {
                mp.release();
            } catch (Exception ignored) {
            }
            mp = null;
        }
    }

    private void playResultSound() {
        stopResultSound();
        try {
            resultMp = new MediaPlayer();
            resultMp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            AssetFileDescriptor afd = getContext().getAssets().openFd("result.mp3");
            resultMp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(),
                    afd.getLength());
            afd.close();
            resultMp.prepare();
            resultMp.start();
        } catch (Exception e) {
            stopResultSound();
        }
    }

    private void stopResultSound() {
        if (resultMp != null) {
            try {
                resultMp.stop();
            } catch (Exception ignored) {
            }
            try {
                resultMp.release();
            } catch (Exception ignored) {
            }
            resultMp = null;
        }
    }

    public void release() {
        releaseMp();
        stopCalib();
        stopResultSound();
        if (pool != null) {
            pool.release();
            pool = null;
        }
    }

    private void toMenu() {
        releaseMp();
        stopCalib();
        stopResultSound();
        state = MENU;
    }

    public boolean onBack() {
        if (state == PLAYING) {
            pauseGame();
            return true;
        }
        if (state == PAUSED) {
            resumeGame();
            return true;
        }
        if (state != MENU) {
            toMenu();
            return true;
        }
        return false;
    }

    // ---------------------------------------------------------------- battle flow

    private void startBattle() {
        stopResultSound();
        mode = BATTLE;
        playerHp = PLAYER_MAX_HP;
        enemyHp = ENEMY_MAX_HP;
        turn = 1;
        drawHand();
        state = PICK;
    }

    private void drawHand() {
        ArrayList<Integer> idx = new ArrayList<Integer>();
        for (int i = 0; i < POOL.length; i++) idx.add(i);
        Collections.shuffle(idx, rng);
        for (int i = 0; i < DRAW_COUNT; i++) hand[i] = idx.get(i);
        picked.clear();
    }

    private void startAttack() {
        playIdx = 0;
        turnMiss = 0;
        startCard();
    }

    private void startCard() {
        curCard = POOL[hand[picked.get(playIdx)]];
        long from = curCard.startSec * 1000L;
        long len = curCard.lenSec * 1000L;
        buildNotes(from, from + len, curCard.coins);
        curCoins = Math.min(curCard.coins, Math.max(1, notes.size()));
        beginSession(from, len);
    }

    /** -1 还没打完, 0 反面, 1 正面, 2 暴击 */
    private int coinState(int g) {
        int cnt = 0;
        float sum = 0;
        for (int i = 0; i < notes.size(); i++) {
            Note n = notes.get(i);
            if (n.coin != g) continue;
            cnt++;
            if (!n.done) return -1;
            sum += n.w;
        }
        if (cnt == 0) return 0;
        float r = sum / cnt;
        if (r >= COIN_CRIT_RATIO) return 2;
        if (r >= COIN_HEADS_RATIO) return 1;
        return 0;
    }

    private void endCard() {
        releaseMp();
        int coins = curCoins;
        lastCoinStates = new int[coins];
        float raw = curCard.base;
        for (int g = 0; g < coins; g++) {
            int s = coinState(g);
            if (s < 0) s = 0;
            lastCoinStates[g] = s;
            if (s == 1) raw += curCard.coinPower;
            else if (s == 2) raw += curCard.coinPower * 1.5f;
        }
        float lv = 1f + (OFFENSE_LV - DEFENSE_LV) / (float) (Math.abs(OFFENSE_LV - DEFENSE_LV) + 25);
        lastCardDmg = Math.round(raw * lv * RESIST[curCard.type]);
        enemyHp = Math.max(0, enemyHp - lastCardDmg);
        state = CARDRES;
        stateWall = SystemClock.uptimeMillis();
    }

    private void afterCardResult() {
        if (enemyHp <= 0) {
            win = true;
            state = BEND;
            playResultSound();
            return;
        }
        playIdx++;
        if (playIdx < PICK_COUNT) {
            startCard();
        } else {
            enemyDmg = 12 + rng.nextInt(9) + turnMiss / 2;
            playerHp = Math.max(0, playerHp - enemyDmg);
            state = ENEMY;
            stateWall = SystemClock.uptimeMillis();
        }
    }

    private void afterEnemy() {
        if (playerHp <= 0) {
            win = false;
            state = BEND;
            return;
        }
        turn++;
        drawHand();
        state = PICK;
    }

    // ---------------------------------------------------------------- timing

    private long computeSong() {
        long now = SystemClock.uptimeMillis();
        long t;
        if (!musicStarted) {
            long el = now - startWall;
            if (el >= PREROLL && mp != null) {
                try {
                    mp.start();
                } catch (Exception ignored) {
                }
                musicStarted = true;
                lastPos = (int) baseMs;
                lastWall = now;
                t = 0;
            } else {
                t = el - PREROLL;
            }
        } else {
            int pos = lastPos;
            try {
                if (mp != null) pos = mp.getCurrentPosition();
            } catch (Exception ignored) {
            }
            if (pos != lastPos) {
                lastPos = pos;
                lastWall = now;
            }
            long dt = now - lastWall;
            if (dt > 250) dt = 250;
            t = lastPos - baseMs + dt;
        }
        if (t < lastSong) t = lastSong; // never go backwards
        lastSong = t;
        return t;
    }

    private int score() {
        return (int) Math.round(1000000.0 * scoreSum / Math.max(1, notes.size()));
    }

    private float accuracy() {
        return scoreSum / Math.max(1, notes.size());
    }

    // ---------------------------------------------------------------- judging

    private void tap(int lane, long evTime) {
        long now = SystemClock.uptimeMillis();
        long ct = computeSong() - offsetMs - (now - evTime);
        fxTime[lane] = now;
        fxColor[lane] = 0xFFFFFFFF;

        Note hit = null;
        for (int i = head; i < notes.size(); i++) {
            Note n = notes.get(i);
            long d = n.t - ct;
            if (d > W_GOOD) break;
            if (n.done || n.lane != lane) continue;
            if (d < -W_GOOD) continue;
            hit = n;
            break;
        }
        if (hit == null) return;
        hit.done = true;
        long err = ct - hit.t; // negative = early
        long ae = Math.abs(err);
        String name;
        int color;
        if (ae <= W_PERFECT) {
            name = "PERFECT";
            color = C_PERFECT;
            hit.w = 1f;
            cPerfect++;
        } else if (ae <= W_GREAT) {
            name = "GREAT";
            color = C_GREAT;
            hit.w = 0.7f;
            cGreat++;
        } else {
            name = "GOOD";
            color = C_GOOD;
            hit.w = 0.4f;
            cGood++;
        }
        scoreSum += hit.w;
        combo++;
        if (combo > maxCombo) maxCombo = combo;
        setJudge(name, ae <= W_PERFECT ? "" : (err < 0 ? "EARLY" : "LATE"), color);
        fxColor[lane] = color;
        if (mode == BATTLE) bossHitTime = now;
        if (pool != null) pool.play(hitId, 1f, 1f, 1, 0, 1f);
    }

    private void miss() {
        combo = 0;
        cMiss++;
        turnMiss++;
        setJudge("MISS", "", C_MISS);
    }

    private void setJudge(String t, String sub, int c) {
        judgeText = t;
        judgeSub = sub;
        judgeColor = c;
        judgeTime = SystemClock.uptimeMillis();
    }

    private void updateGame() {
        songNow = computeSong();
        long ct = songNow - offsetMs;
        while (head < notes.size()) {
            Note n = notes.get(head);
            if (n.done) {
                head++;
            } else if (ct - n.t > W_GOOD) {
                n.done = true;
                miss();
                head++;
            } else {
                break;
            }
        }
        long lastT = notes.isEmpty() ? 0 : notes.get(notes.size() - 1).t;
        if (mode == FREE) {
            if (songEnded || (head >= notes.size() && ct - lastT > 1500)) finishGame();
        } else {
            if (head >= notes.size() && ct - lastT > 1000) endCard();
        }
    }

    // ---------------------------------------------------------------- 校准

    private void startCalib() {
        releaseMp();
        stopResultSound();
        stopCalib();
        try {
            calMp = new MediaPlayer();
            calMp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            AssetFileDescriptor afd = getContext().getAssets().openFd("metronome.wav");
            calMp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            calMp.setLooping(true);
            calMp.prepare();
            calMp.start();
        } catch (Exception e) {
            Toast.makeText(getContext(), "节拍器加载失败: " + e, Toast.LENGTH_LONG).show();
            stopCalib();
            return;
        }
        calLastPos = 0;
        calLastWall = SystemClock.uptimeMillis();
        calTaps = 0;
        calHasD = false;
        calSamples.clear();
        Arrays.fill(held, 0);
        state = CALIB;
    }

    private void stopCalib() {
        if (calMp != null) {
            try {
                calMp.stop();
            } catch (Exception ignored) {
            }
            try {
                calMp.release();
            } catch (Exception ignored) {
            }
            calMp = null;
        }
    }

    /** 节拍器文件内的播放位置(ms), 用和游戏里一样的方式插值 */
    private long calTime() {
        long now = SystemClock.uptimeMillis();
        int pos = calLastPos;
        try {
            if (calMp != null) pos = calMp.getCurrentPosition();
        } catch (Exception ignored) {
        }
        if (pos != calLastPos) {
            calLastPos = pos;
            calLastWall = now;
        }
        long dt = now - calLastWall;
        if (dt > 250) dt = 250;
        return calLastPos + dt;
    }

    private int calMedian() {
        ArrayList<Integer> a = new ArrayList<Integer>(calSamples);
        Collections.sort(a);
        int n = a.size();
        if (n == 0) return 0;
        if (n % 2 == 1) return a.get(n / 2);
        return (a.get(n / 2 - 1) + a.get(n / 2)) / 2;
    }

    private void calSetOffset(int v) {
        offsetMs = Math.max(-300, Math.min(300, v));
        prefs.edit().putInt("offset", offsetMs).apply();
    }

    private void calTouch(float x, float y, long evTime) {
        if (calMinus.contains(x, y)) {
            calSetOffset(offsetMs - 5);
        } else if (calPlus.contains(x, y)) {
            calSetOffset(offsetMs + 5);
        } else if (calApply.contains(x, y)) {
            if (calSamples.size() >= 6) calSetOffset(calMedian());
        } else if (calReset.contains(x, y)) {
            calTaps = 0;
            calHasD = false;
            calSamples.clear();
        } else if (calDone.contains(x, y)) {
            toMenu();
        } else {
            long now = SystemClock.uptimeMillis();
            long t = calTime() - (now - evTime);
            long ph = ((t % CAL_BEAT) + CAL_BEAT) % CAL_BEAT;
            int d = (int) (ph < CAL_BEAT / 2 ? ph : ph - CAL_BEAT);  // 正数 = 点晚了
            calTaps++;
            calLastD = d;
            calHasD = true;
            if (calTaps > CAL_WARMUP) {
                calSamples.add(Integer.valueOf(d));
                if (calSamples.size() > CAL_KEEP) calSamples.remove(0);
            }
            fxTime[1] = now;
            fxColor[1] = Math.abs(d) <= 30 ? GREEN : (Math.abs(d) <= 80 ? C_PERFECT : RED);
        }
    }

    private void drawCalib(Canvas c, long now) {
        float cx = W / 2f;
        long t = calTime();
        float approach = 1000f;
        float lineYc = H * 0.46f;
        float topY = H * 0.14f;

        text(c, "判定校准", cx, H * 0.075f, W * 0.07f, 0xFFFFFFFF, Paint.Align.CENTER);
        text(c, "听着节拍器,在音符落到线上的瞬间点屏幕", cx, H * 0.112f, W * 0.036f,
                0xCCFFFFFF, Paint.Align.CENTER);

        // 下落音符 + 判定线
        float nw = W * 0.34f, nh = H * 0.03f;
        long base = (t / CAL_BEAT) * CAL_BEAT;
        for (int k = -1; k <= 2; k++) {
            long tc = base + (long) k * CAL_BEAT;
            float dt = tc - t;
            if (dt > approach || dt < -120) continue;
            float s = 1f - dt / approach;
            float y = topY + (lineYc - topY) * s;
            tmp.set(cx - nw / 2, y - nh / 2, cx + nw / 2, y + nh / 2);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x5522D3EE);
            tmp.inset(-4 * dp, -4 * dp);
            c.drawRoundRect(tmp, nh, nh, p);
            tmp.inset(4 * dp, 4 * dp);
            p.setColor(CYAN);
            c.drawRoundRect(tmp, nh / 2, nh / 2, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2 * dp);
            p.setColor(0xFFFFFFFF);
            c.drawRoundRect(tmp, nh / 2, nh / 2, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x4422D3EE);
        c.drawRect(cx - W * 0.3f, lineYc - 5 * dp, cx + W * 0.3f, lineYc + 5 * dp, p);
        p.setColor(0xFFBFF4FF);
        c.drawRect(cx - W * 0.3f, lineYc - 1.5f * dp, cx + W * 0.3f, lineYc + 1.5f * dp, p);

        // 节拍脉冲
        long ph = ((t % CAL_BEAT) + CAL_BEAT) % CAL_BEAT;
        float pulse = Math.max(0f, 1f - ph / 140f);
        glowCircle(c, cx, lineYc, W * (0.035f + 0.03f * pulse), pulse > 0 ? 0xFFFFFFFF : 0x6622D3EE);
        long age = now - fxTime[1];
        if (fxTime[1] != 0 && age < 300) {
            float pr = age / 300f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3 * dp);
            p.setColor((fxColor[1] & 0x00FFFFFF) | ((int) ((1f - pr) * 220) << 24));
            c.drawCircle(cx, lineYc, W * (0.08f + 0.18f * pr), p);
        }

        // 数值
        if (calHasD) {
            int col = Math.abs(calLastD) <= 30 ? GREEN : (Math.abs(calLastD) <= 80 ? C_PERFECT : RED);
            text(c, (calLastD > 0 ? "晚 " : (calLastD < 0 ? "早 " : "")) + Math.abs(calLastD) + " ms",
                    cx, H * 0.545f, W * 0.07f, col, Paint.Align.CENTER);
        } else {
            text(c, "开始点吧", cx, H * 0.545f, W * 0.06f, 0x88FFFFFF, Paint.Align.CENTER);
        }
        String info;
        if (calTaps < CAL_WARMUP) info = "热身中… " + calTaps + "/" + CAL_WARMUP;
        else info = "已采样 " + calSamples.size() + "/" + CAL_KEEP + (calSamples.size() >= 6
                ? "    测得 " + fmtMs(calMedian()) : "    (至少 6 次)");
        text(c, info, cx, H * 0.595f, W * 0.04f, 0xFFFFFFFF, Paint.Align.CENTER);
        text(c, "当前偏移 " + fmtMs(offsetMs), cx, H * 0.64f, W * 0.04f, ORANGE,
                Paint.Align.CENTER);

        button(c, calMinus, "-5", 0xFF3B6EA5);
        button(c, calPlus, "+5", 0xFF3B6EA5);
        button(c, calApply, calSamples.size() >= 6 ? "应用测得值 " + fmtMs(calMedian())
                : "再点几次…", calSamples.size() >= 6 ? PINK : 0xFF3B6EA5);
        button(c, calReset, "重测", CYAN);
        button(c, calDone, "完成", CYAN);
        text(c, "点晚了=偏移为正。换耳机/蓝牙后需要重新校准", cx, H * 0.965f, W * 0.032f,
                0x88FFFFFF, Paint.Align.CENTER);
    }

    private String fmtMs(int v) {
        return (v > 0 ? "+" : "") + v + " ms";
    }

    // ---------------------------------------------------------------- touch

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            int i = e.getActionIndex();
            onDown(e.getPointerId(i), e.getX(i), e.getY(i), e.getEventTime());
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP) {
            int id = e.getPointerId(e.getActionIndex());
            if (id >= 0 && id < ptrLane.length && ptrLane[id] >= 0) {
                held[ptrLane[id]] = Math.max(0, held[ptrLane[id]] - 1);
                ptrLane[id] = -1;
            }
        } else if (a == MotionEvent.ACTION_CANCEL) {
            Arrays.fill(held, 0);
            Arrays.fill(ptrLane, -1);
        }
        return true;
    }

    private void onDown(int id, float x, float y, long evTime) {
        if (state == MENU) {
            if (startBtn.contains(x, y)) {
                startGame();
            } else if (battleBtn.contains(x, y)) {
                startBattle();
            } else if (calBtn.contains(x, y)) {
                startCalib();
            } else if (spdMinus.contains(x, y)) {
                speedLevel = Math.max(1, speedLevel - 1);
                prefs.edit().putInt("speed", speedLevel).apply();
            } else if (spdPlus.contains(x, y)) {
                speedLevel = Math.min(10, speedLevel + 1);
                prefs.edit().putInt("speed", speedLevel).apply();
            }
        } else if (state == CALIB) {
            calTouch(x, y, evTime);
        } else if (state == PICK) {
            for (int i = 0; i < DRAW_COUNT; i++) {
                if (cardRects[i].contains(x, y)) {
                    Integer key = Integer.valueOf(i);
                    if (picked.contains(key)) picked.remove(key);
                    else if (picked.size() < PICK_COUNT) picked.add(key);
                    return;
                }
            }
            if (picked.size() == PICK_COUNT && atkBtn.contains(x, y)) startAttack();
        } else if (state == CARDRES) {
            if (SystemClock.uptimeMillis() - stateWall > 500) afterCardResult();
        } else if (state == ENEMY) {
            if (SystemClock.uptimeMillis() - stateWall > 500) afterEnemy();
        } else if (state == BEND) {
            if (againBtn.contains(x, y)) startBattle();
            else if (menuBtn.contains(x, y)) toMenu();
        } else if (state == PAUSED) {
            if (resumeBtn.contains(x, y)) {
                resumeGame();
            } else if (restartBtn.contains(x, y)) {
                if (mode == BATTLE) {
                    turnMiss = 0;
                    startCard();
                } else {
                    startGame();
                }
            } else if (quitBtn.contains(x, y)) {
                toMenu();
            }
        } else if (state == RESULT) {
            if (againBtn.contains(x, y)) {
                startGame();
            } else if (menuBtn.contains(x, y)) {
                toMenu();
            }
        } else if (state == PLAYING) {
            if (pauseBtn.contains(x, y)) {
                pauseGame();
                return;
            }
            int lane = (int) (x / laneW);
            if (lane < 0) lane = 0;
            if (lane >= LANES) lane = LANES - 1;
            if (id >= 0 && id < ptrLane.length) {
                ptrLane[id] = lane;
                held[lane]++;
            }
            tap(lane, evTime);
        }
    }

    // ---------------------------------------------------------------- drawing helpers

    private void glowCircle(Canvas c, float cx, float cy, float r, int color) {
        p.setStyle(Paint.Style.FILL);
        for (int k = 0; k < 4; k++) {
            int alpha = 28 + k * 14;
            p.setColor((color & 0x00FFFFFF) | (alpha << 24));
            c.drawCircle(cx, cy, r * (1.9f - k * 0.3f), p);
        }
        p.setColor(color);
        c.drawCircle(cx, cy, r, p);
    }

    private void starPath(Path pa, float cx, float cy, float ro, float ri, int n, float rot) {
        pa.reset();
        for (int i = 0; i < n * 2; i++) {
            float ang = (float) (rot + Math.PI * i / n);
            float rad = (i % 2 == 0) ? ro : ri;
            float x = cx + (float) Math.cos(ang) * rad;
            float y = cy + (float) Math.sin(ang) * rad;
            if (i == 0) pa.moveTo(x, y);
            else pa.lineTo(x, y);
        }
        pa.close();
    }

    private void hexPath(Path pa, float cx, float cy, float r) {
        pa.reset();
        for (int i = 0; i < 6; i++) {
            float ang = (float) Math.toRadians(-90 + 60 * i);
            float x = cx + (float) Math.cos(ang) * r;
            float y = cy + (float) Math.sin(ang) * r;
            if (i == 0) pa.moveTo(x, y);
            else pa.lineTo(x, y);
        }
        pa.close();
    }

    /** 发光的圆形图标: 彩色光球 + 白色星星 */
    private void orb(Canvas c, float cx, float cy, float r, int color) {
        glowCircle(c, cx, cy, r, color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1.5f * dp, r * 0.08f));
        p.setColor(0xFFFFFFFF);
        c.drawCircle(cx, cy, r * 0.88f, p);
        starPath(path, cx, cy, r * 0.66f, r * 0.16f, 4, (float) (-Math.PI / 2));
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        c.drawPath(path, p);
    }

    private void neonRect(Canvas c, RectF r, int color, float radius, int fill) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(fill);
        c.drawRoundRect(r, radius, radius, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(5 * dp);
        p.setColor((color & 0x00FFFFFF) | 0x33000000);
        c.drawRoundRect(r, radius, radius, p);
        p.setStrokeWidth(2 * dp);
        p.setColor(color);
        c.drawRoundRect(r, radius, radius, p);
    }

    private void text(Canvas c, String s, float x, float y, float size, int color,
                      Paint.Align align) {
        p.setStyle(Paint.Style.FILL);
        p.setTextSize(size);
        p.setColor(color);
        p.setTextAlign(align);
        c.drawText(s, x, y, p);
    }

    private void button(Canvas c, RectF r, String label, int color) {
        neonRect(c, r, color, r.height() / 2.6f, 0xCC061630);
        text(c, label, r.centerX(), r.centerY() + r.height() * 0.17f, r.height() * 0.5f,
                0xFFFFFFFF, Paint.Align.CENTER);
    }

    private void bar(Canvas c, float x, float y, float w, float h, float frac, int color) {
        frac = Math.max(0f, Math.min(1f, frac));
        tmp.set(x, y, x + w, y + h);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xCC050E22);
        c.drawRoundRect(tmp, h / 2, h / 2, p);
        if (frac > 0) {
            p.setColor(color);
            tmp.set(x + dp, y + dp, x + dp + (w - 2 * dp) * frac, y + h - dp);
            c.drawRoundRect(tmp, h / 2, h / 2, p);
        }
        tmp.set(x, y, x + w, y + h);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.5f * dp);
        p.setColor((color & 0x00FFFFFF) | 0xAA000000);
        c.drawRoundRect(tmp, h / 2, h / 2, p);
    }

    private void hpBars(Canvas c, float y) {
        float bw = W * 0.8f, bx = W * 0.1f, bh = H * 0.018f;
        text(c, "炼狱天使  " + enemyHp + "/" + ENEMY_MAX_HP, bx, y, W * 0.037f, 0xFFFFFFFF,
                Paint.Align.LEFT);
        bar(c, bx, y + H * 0.008f, bw, bh, enemyHp / (float) ENEMY_MAX_HP, RED);
        float y2 = y + H * 0.065f;
        text(c, "你  " + playerHp + "/" + PLAYER_MAX_HP, bx, y2, W * 0.037f, 0xFFFFFFFF,
                Paint.Align.LEFT);
        bar(c, bx, y2 + H * 0.008f, bw, bh, playerHp / (float) PLAYER_MAX_HP, GREEN);
    }

    private void pips(Canvas c, float cx, float y, float r, int[] st) {
        float gap = r * 2.8f;
        float x0 = cx - (st.length - 1) * gap / 2f;
        for (int i = 0; i < st.length; i++) {
            float x = x0 + i * gap;
            p.setStyle(Paint.Style.FILL);
            if (st[i] == 2) {
                glowCircle(c, x, y, r, PINK);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2 * dp);
                p.setColor(C_PERFECT);
                c.drawCircle(x, y, r * 1.4f, p);
            } else if (st[i] == 1) {
                glowCircle(c, x, y, r, C_PERFECT);
            } else if (st[i] == 0) {
                p.setColor(0xFF4A5568);
                c.drawCircle(x, y, r, p);
            } else {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2 * dp);
                p.setColor(0xAAFFFFFF);
                c.drawCircle(x, y, r, p);
            }
        }
    }

    private int maxDmg(Card k) {
        float lv = 1f + (OFFENSE_LV - DEFENSE_LV) / (float) (Math.abs(OFFENSE_LV - DEFENSE_LV) + 25);
        float raw = k.base + k.coinPower * 1.5f * k.coins;
        return Math.round(raw * lv * RESIST[k.type]);
    }

    private float lx(int boundary, float scale) {
        return W / 2f + (boundary * laneW - W / 2f) * scale;
    }

    // ---- 背景 / 场景 ----

    private void drawBackdrop(Canvas c, long now) {
        c.drawRect(0, 0, W, H, bgPaint);
        c.drawRect(0, 0, W, H * 0.7f, glowPaint);
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < px.length; i++) {
            float y = ((py[i] - now * pv[i]) % H + H) % H;
            p.setColor(0x7722D3EE);
            c.drawCircle(px[i], y, ps[i], p);
        }
    }

    private void drawEmblem(Canvas c, float cx, float cy, float size, long now) {
        float wob = (float) Math.sin(now / 900.0) * 4f;
        c.save();
        c.rotate(45 + wob, cx, cy);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2 * dp);
        p.setColor(0x6622D3EE);
        tmp.set(cx - size * 1.25f, cy - size * 1.25f, cx + size * 1.25f, cy + size * 1.25f);
        c.drawRoundRect(tmp, 8 * dp, 8 * dp, p);
        p.setColor(0xAA22D3EE);
        p.setStrokeWidth(3 * dp);
        tmp.set(cx - size, cy - size, cx + size, cy + size);
        c.drawRoundRect(tmp, 8 * dp, 8 * dp, p);
        c.restore();
        starPath(path, cx, cy, size * 0.75f, size * 0.12f, 4, (float) (-Math.PI / 2));
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xCC9BE8FF);
        c.drawPath(path, p);
        glowCircle(c, cx, cy, size * 0.09f, 0xFFFFFFFF);
    }

    private void drawFramedBitmap(Canvas c, Bitmap b, RectF box, int color) {
        float bw = b.getWidth(), bh = b.getHeight();
        float boxAspect = box.width() / box.height();
        Rect src = new Rect();
        if (bw / bh > boxAspect) {
            int sw = (int) (bh * boxAspect);
            src.set((int) ((bw - sw) / 2), 0, (int) ((bw + sw) / 2), (int) bh);
        } else {
            int sh = (int) (bw / boxAspect);
            src.set(0, 0, (int) bw, sh);   // 竖图保留上半部分(头像一般在上面)
        }
        clip.reset();
        clip.addRoundRect(box, 14 * dp, 14 * dp, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        c.drawBitmap(b, src, box, bmpPaint);
        c.restore();
        neonRect(c, box, color, 14 * dp, 0x00000000);
    }

    private void drawCutBitmap(Canvas c, Bitmap b, RectF box, float dx, float dy) {
        float sc = Math.min(box.width() / b.getWidth(), box.height() / b.getHeight());
        float w = b.getWidth() * sc, h = b.getHeight() * sc;
        float x = box.centerX() - w / 2f + dx, y = box.bottom - h + dy;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x55000000);
        tmp.set(box.centerX() - w * 0.4f + dx, box.bottom - h * 0.04f,
                box.centerX() + w * 0.4f + dx, box.bottom + h * 0.03f);
        c.drawOval(tmp, p);
        tmp.set(x, y, x + w, y + h);
        c.drawBitmap(b, null, tmp, bmpPaint);
    }

    private void drawScene(Canvas c, long now) {
        drawEmblem(c, W / 2f, H * 0.27f, W * 0.13f, now);
        float bob = (float) Math.sin(now / 500.0) * 3 * dp;

        // 我方
        if (heroBmp != null) {
            if (heroCut) drawCutBitmap(c, heroBmp, heroBox, 0, bob);
            else drawFramedBitmap(c, heroBmp, heroBox, CYAN);
        } else {
            orb(c, W * 0.24f, sceneBot - H * 0.16f + bob, W * 0.10f, ORANGE);
        }

        // 敌方 (被打中时抖一下)
        float shake = 0;
        long age = now - bossHitTime;
        if (age >= 0 && age < 220) shake = (float) Math.sin(age * 0.09) * 7 * dp * (1f - age / 220f);
        if (bossBmp != null) {
            if (bossCut) drawCutBitmap(c, bossBmp, bossBox, shake, -bob);
            else drawFramedBitmap(c, bossBmp, bossBox, RED);
        } else {
            float bx = W * 0.77f + shake, by = sceneBot - H * 0.17f - bob;
            glowCircle(c, bx, by, W * 0.07f, 0xFF7A0A2A);
            starPath(path, bx, by, W * 0.17f, W * 0.05f, 6, (float) (-Math.PI / 2));
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF12020F);
            c.drawPath(path, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.5f * dp);
            p.setColor(RED);
            c.drawPath(path, p);
            glowCircle(c, bx, by, W * 0.018f, RED);
        }
        // 场景和轨道之间的分隔光带
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x6622D3EE);
        c.drawRect(0, sceneBot + H * 0.005f, W, sceneBot + H * 0.009f, p);
    }

    private void avatar(Canvas c, float cx, float cy, float r, Bitmap b, int color, int iconColor) {
        hexPath(path, cx, cy, r);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF06142C);
        c.drawPath(path, p);
        if (b != null) {
            Rect src = new Rect();
            int bw = b.getWidth(), bh = b.getHeight();
            int side = Math.min(bw, bh);
            src.set((bw - side) / 2, 0, (bw + side) / 2, side);
            hexPath(clip, cx, cy, r * 0.92f);
            c.save();
            c.clipPath(clip);
            tmp.set(cx - r, cy - r, cx + r, cy + r);
            c.drawBitmap(b, src, tmp, bmpPaint);
            c.restore();
        } else {
            starPath(clip, cx, cy, r * 0.62f, r * 0.14f, 4, (float) (-Math.PI / 2));
            p.setColor(iconColor);
            c.drawPath(clip, p);
        }
        hexPath(path, cx, cy, r);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4 * dp);
        p.setColor((color & 0x00FFFFFF) | 0x44000000);
        c.drawPath(path, p);
        p.setStrokeWidth(2 * dp);
        p.setColor(color);
        c.drawPath(path, p);
    }

    private void drawHud(Canvas c, float frac) {
        float r = H * 0.042f, cy = H * 0.062f;
        avatar(c, W * 0.085f, cy, r, heroBmp, PINK, 0xFFFFD6EA);
        float bh = H * 0.016f;
        if (mode == BATTLE) {
            avatar(c, W * 0.915f, cy, r, bossBmp, RED, 0xFFFFC9CF);
            bar(c, W * 0.17f, cy - bh * 0.9f, W * 0.22f, bh, playerHp / (float) PLAYER_MAX_HP, GREEN);
            bar(c, W * 0.61f, cy - bh * 0.9f, W * 0.22f, bh, enemyHp / (float) ENEMY_MAX_HP, RED);
            text(c, String.valueOf(playerHp), W * 0.17f, cy + bh * 2.6f, W * 0.032f,
                    0xCCFFFFFF, Paint.Align.LEFT);
            text(c, String.valueOf(enemyHp), W * 0.83f, cy + bh * 2.6f, W * 0.032f,
                    0xCCFFFFFF, Paint.Align.RIGHT);
        } else {
            bar(c, W * 0.17f, cy - bh * 0.9f, W * 0.22f, bh, frac, CYAN);
            text(c, String.format(Locale.US, "%07d", score()), W * 0.95f, cy + H * 0.012f,
                    W * 0.07f, 0xFFFFFFFF, Paint.Align.RIGHT);
        }
        // 中间六边形 = 暂停键
        hexPath(path, W / 2f, cy, H * 0.04f);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF06142C);
        c.drawPath(path, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4 * dp);
        p.setColor(0x4422D3EE);
        c.drawPath(path, p);
        p.setStrokeWidth(2 * dp);
        p.setColor(CYAN);
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        c.drawRect(W / 2f - 6 * dp, cy - 8 * dp, W / 2f - 2 * dp, cy + 8 * dp, p);
        c.drawRect(W / 2f + 2 * dp, cy - 8 * dp, W / 2f + 6 * dp, cy + 8 * dp, p);
        if (mode == BATTLE) {
            text(c, "T" + turn, W / 2f, cy + H * 0.062f, W * 0.036f, 0xAAFFFFFF,
                    Paint.Align.CENTER);
        }
    }

    // ---------------------------------------------------------------- screens

    @Override
    protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        drawBackdrop(c, now);
        if (state == PLAYING) updateGame();
        switch (state) {
            case MENU:
                drawMenu(c, now);
                break;
            case PLAYING:
            case PAUSED:
                drawGame(c, now);
                if (state == PAUSED) drawPause(c);
                break;
            case RESULT:
                drawResult(c);
                break;
            case PICK:
                drawPick(c);
                break;
            case CARDRES:
                drawCardRes(c);
                if (now - stateWall > 2600) afterCardResult();
                break;
            case ENEMY:
                drawEnemy(c);
                if (now - stateWall > 2400) afterEnemy();
                break;
            case BEND:
                drawBattleEnd(c);
                break;
            case CALIB:
                drawCalib(c, now);
                break;
            default:
                break;
        }
        postInvalidateOnAnimation();
    }

    private void drawMenu(Canvas c, long now) {
        float cx = W / 2f;
        drawEmblem(c, cx, H * 0.205f, W * 0.15f, now);
        text(c, "HELL ANGELS", cx, H * 0.385f, W * 0.115f, 0xFFFFFFFF, Paint.Align.CENTER);
        text(c, "4K RHYTHM  ×  CARD BATTLE", cx, H * 0.425f, W * 0.036f, CYAN,
                Paint.Align.CENTER);
        text(c, "最高分  " + String.format(Locale.US, "%07d", best), cx, H * 0.465f,
                W * 0.045f, C_PERFECT, Paint.Align.CENTER);

        button(c, startBtn, "自由模式", CYAN);
        button(c, battleBtn, "战斗模式", PINK);

        float r1 = H * 0.72f, r2 = H * 0.80f;
        button(c, calBtn, "判定校准   " + (offsetMs > 0 ? "+" : "") + offsetMs + " ms", ORANGE);
        button(c, spdMinus, "-", 0xFF3B6EA5);
        button(c, spdPlus, "+", 0xFF3B6EA5);
        text(c, "流速 " + speedLevel, cx, r2 + W * 0.02f, W * 0.05f, 0xFFFFFFFF,
                Paint.Align.CENTER);
        text(c, "换耳机或蓝牙设备后,记得重新校准一次", cx, H * 0.875f,
                W * 0.032f, 0x88FFFFFF, Paint.Align.CENTER);
        text(c, "点四条轨道打击音符,点上方六边形或按返回键暂停", cx, H * 0.915f, W * 0.032f,
                0x88FFFFFF, Paint.Align.CENTER);
    }

    private void drawGame(Canvas c, long now) {
        long ct = songNow - offsetMs;
        float approach = 2000f - speedLevel * 150f;
        float prog = Math.max(0f, Math.min(1f, songNow / (float) sessionLen));

        drawScene(c, now);

        // ---- 透视轨道 ----
        path.reset();
        path.moveTo(lx(0, topScale), hwTop);
        path.lineTo(lx(LANES, topScale), hwTop);
        path.lineTo(W, lineY);
        path.lineTo(0, lineY);
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x990A1F44);
        c.drawPath(path, p);

        // 按住的轨道高亮
        for (int i = 0; i < LANES; i++) {
            if (held[i] > 0) {
                path.reset();
                path.moveTo(lx(i, topScale), hwTop);
                path.lineTo(lx(i + 1, topScale), hwTop);
                path.lineTo((i + 1) * laneW, lineY);
                path.lineTo(i * laneW, lineY);
                path.close();
                p.setStyle(Paint.Style.FILL);
                p.setColor((LANE_COLORS[i] & 0x00FFFFFF) | 0x44000000);
                c.drawPath(path, p);
            }
        }

        // 随节拍滚动的横线 (BPM 94.25, 第一拍 390ms)
        double beat = 60000.0 / 94.25;
        double abs = ct + baseMs;
        int m0 = (int) Math.floor((abs - 390) / beat) - 1;
        int m1 = (int) Math.ceil((abs + approach - 390) / beat) + 1;
        p.setStyle(Paint.Style.STROKE);
        for (int m = m0; m <= m1; m++) {
            double tb = 390 + m * beat;
            float s = (float) (1.0 - (tb - abs) / approach);
            if (s < 0f || s > 1f) continue;
            float y = hwTop + (lineY - hwTop) * s;
            float sc = topScale + (1f - topScale) * s;
            boolean strong = (m & 3) == 0;
            p.setStrokeWidth(strong ? 1.6f * dp : dp);
            p.setColor(strong ? 0x6622D3EE : 0x2E22D3EE);
            c.drawLine(lx(0, sc), y, lx(LANES, sc), y, p);
        }
        // 轨道竖线
        p.setStrokeWidth(1.5f * dp);
        p.setColor(0x7722D3EE);
        for (int i = 0; i <= LANES; i++) c.drawLine(lx(i, topScale), hwTop, i * laneW, lineY, p);

        // 判定线
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x4422D3EE);
        c.drawRect(0, lineY - 5 * dp, W, lineY + 5 * dp, p);
        p.setColor(0xFFBFF4FF);
        c.drawRect(0, lineY - 1.5f * dp, W, lineY + 1.5f * dp, p);

        // 打击特效
        for (int i = 0; i < LANES; i++) {
            long age = now - fxTime[i];
            if (fxTime[i] != 0 && age < 300) {
                float pr = age / 300f;
                int alpha = (int) ((1f - pr) * 220);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(3 * dp);
                p.setColor((fxColor[i] & 0x00FFFFFF) | (alpha << 24));
                c.drawCircle(i * laneW + laneW / 2f, lineY, laneW * (0.25f + 0.45f * pr), p);
            }
        }

        // 音符 (近大远小)
        for (int i = head; i < notes.size(); i++) {
            Note n = notes.get(i);
            float dt = n.t - ct;
            if (dt > approach) break;
            if (n.done) continue;
            float sN = 1f - dt / approach;
            float y = hwTop + (lineY - hwTop) * sN;
            float sc = topScale + (1f - topScale) * sN;
            float cxN = W / 2f + ((n.lane + 0.5f) * laneW - W / 2f) * sc;
            float hw = laneW * sc * 0.43f, hh = noteH * sc / 2f;
            tmp.set(cxN - hw, y - hh, cxN + hw, y + hh);
            int col = LANE_COLORS[n.lane];
            p.setStyle(Paint.Style.FILL);
            p.setColor((col & 0x00FFFFFF) | 0x55000000);
            tmp.inset(-3 * dp * sc, -3 * dp * sc);
            c.drawRoundRect(tmp, hh, hh, p);
            tmp.inset(3 * dp * sc, 3 * dp * sc);
            p.setColor(col);
            c.drawRoundRect(tmp, hh * 0.8f, hh * 0.8f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f, 2 * dp * sc));
            p.setColor(0xFFFFFFFF);
            c.drawRoundRect(tmp, hh * 0.8f, hh * 0.8f, p);
        }

        // 底部四个打击键
        float gap = 4 * dp;
        for (int i = 0; i < LANES; i++) {
            tmp.set(i * laneW + gap, padTop, (i + 1) * laneW - gap, padBot);
            boolean down = held[i] > 0;
            int col = LANE_COLORS[i];
            neonRect(c, tmp, col, 12 * dp, down ? ((col & 0x00FFFFFF) | 0x88000000) : 0xCC061630);
            orb(c, tmp.centerX(), tmp.centerY(), Math.min(tmp.width(), tmp.height()) * 0.3f,
                    col);
        }

        // ---- HUD ----
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x33FFFFFF);
        c.drawRect(0, 0, W, 3 * dp, p);
        p.setColor(PINK);
        c.drawRect(0, 0, W * prog, 3 * dp, p);
        drawHud(c, prog);

        if (mode == BATTLE && curCard != null) {
            text(c, (playIdx + 1) + "/" + PICK_COUNT + "  " + curCard.name, W / 2f, H * 0.155f,
                    W * 0.045f, TYPE_COLOR[curCard.type], Paint.Align.CENTER);
            int[] st = new int[curCoins];
            for (int g = 0; g < curCoins; g++) st[g] = coinState(g);
            pips(c, W / 2f, H * 0.19f, 6 * dp, st);
        }

        if (combo >= 2) {
            text(c, String.valueOf(combo), W / 2f, sceneBot - H * 0.015f, W * 0.13f,
                    0xFFFFFFFF, Paint.Align.CENTER);
            text(c, "COMBO", W / 2f, sceneBot + H * 0.025f, W * 0.035f, 0xAAFFFFFF,
                    Paint.Align.CENTER);
        }
        long ja = now - judgeTime;
        if (judgeText.length() > 0 && ja < 500) {
            int alpha = ja < 300 ? 255 : (int) (255 * (1 - (ja - 300) / 200f));
            text(c, judgeText, W / 2f, H * 0.66f, W * 0.08f,
                    (judgeColor & 0x00FFFFFF) | (alpha << 24), Paint.Align.CENTER);
            if (judgeSub.length() > 0) {
                text(c, judgeSub, W / 2f, H * 0.695f, W * 0.038f,
                        (0x00FFFFFF) | (alpha << 24), Paint.Align.CENTER);
            }
        }
    }

    private void drawPause(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xCC000814);
        c.drawRect(0, 0, W, H, p);
        text(c, "暂 停", W / 2f, H * 0.30f, W * 0.1f, 0xFFFFFFFF, Paint.Align.CENTER);
        button(c, resumeBtn, "继 续", PINK);
        button(c, restartBtn, mode == BATTLE ? "重打这张卡" : "重新开始", CYAN);
        button(c, quitBtn, "返回菜单", CYAN);
    }

    private void drawResult(Canvas c) {
        float cx = W / 2f;
        float acc = accuracy();
        String g = acc >= 0.97f ? "S" : acc >= 0.92f ? "A" : acc >= 0.85f ? "B"
                : acc >= 0.75f ? "C" : "D";
        text(c, g, cx, H * 0.26f, W * 0.34f, C_PERFECT, Paint.Align.CENTER);
        if (cMiss == 0 && !notes.isEmpty()) {
            text(c, (cGreat == 0 && cGood == 0) ? "ALL PERFECT" : "FULL COMBO", cx, H * 0.31f,
                    W * 0.05f, PINK, Paint.Align.CENTER);
        }
        text(c, String.format(Locale.US, "%07d", score()), cx, H * 0.39f, W * 0.12f,
                0xFFFFFFFF, Paint.Align.CENTER);
        text(c, newBest ? "NEW BEST!" : "最高分 " + String.format(Locale.US, "%07d", best),
                cx, H * 0.43f, W * 0.04f, newBest ? PINK : 0x88FFFFFF,
                Paint.Align.CENTER);
        text(c, String.format(Locale.US, "准确率 %.2f%%    最大连击 %d", acc * 100f, maxCombo),
                cx, H * 0.49f, W * 0.045f, 0xFFFFFFFF, Paint.Align.CENTER);
        text(c, "PERFECT  " + cPerfect, cx, H * 0.55f, W * 0.05f, C_PERFECT, Paint.Align.CENTER);
        text(c, "GREAT  " + cGreat, cx, H * 0.60f, W * 0.05f, C_GREAT, Paint.Align.CENTER);
        text(c, "GOOD  " + cGood, cx, H * 0.65f, W * 0.05f, C_GOOD, Paint.Align.CENTER);
        text(c, "MISS  " + cMiss, cx, H * 0.70f, W * 0.05f, C_MISS, Paint.Align.CENTER);
        button(c, againBtn, "再来一次", PINK);
        button(c, menuBtn, "返回菜单", CYAN);
    }

    // ---- battle screens ----

    private void drawPick(Canvas c) {
        float cx = W / 2f;
        text(c, "第 " + turn + " 回合", cx, H * 0.05f, W * 0.055f, 0xFFFFFFFF,
                Paint.Align.CENTER);
        hpBars(c, H * 0.085f);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            if (i > 0) sb.append("   ");
            sb.append(TYPE_NAME[i]).append(RESIST_NAME[i]).append("x").append(RESIST[i]);
        }
        text(c, sb.toString(), cx, H * 0.235f, W * 0.036f, 0xCCFFFFFF, Paint.Align.CENTER);
        text(c, "选 " + PICK_COUNT + " 张卡,点选顺序就是出牌顺序 (" + picked.size() + "/"
                + PICK_COUNT + ")", cx, H * 0.275f, W * 0.038f, C_PERFECT, Paint.Align.CENTER);

        for (int i = 0; i < DRAW_COUNT; i++) {
            Card k = POOL[hand[i]];
            RectF r = cardRects[i];
            int order = picked.indexOf(Integer.valueOf(i));
            boolean sel = order >= 0;
            int col = TYPE_COLOR[k.type];
            neonRect(c, r, sel ? 0xFFFFFFFF : col, 12 * dp, sel ? 0xDD14305E : 0xCC061630);
            orb(c, r.centerX(), r.top + r.height() * 0.30f, r.width() * 0.19f, col);
            text(c, k.name, r.centerX(), r.top + r.height() * 0.64f, r.width() * 0.19f,
                    0xFFFFFFFF, Paint.Align.CENTER);
            int[] st = new int[k.coins];
            Arrays.fill(st, 1);
            pips(c, r.centerX(), r.top + r.height() * 0.76f, 4f * dp, st);
            text(c, k.base + "+" + k.coinPower + "x" + k.coins + "  最高" + maxDmg(k),
                    r.centerX(), r.top + r.height() * 0.93f, r.width() * 0.115f,
                    0xBBFFFFFF, Paint.Align.CENTER);
            text(c, TYPE_NAME[k.type], r.left + 10 * dp, r.top + 20 * dp, 14 * dp, col,
                    Paint.Align.LEFT);
            if (sel) {
                glowCircle(c, r.right - 14 * dp, r.top + 14 * dp, 11 * dp, PINK);
                text(c, String.valueOf(order + 1), r.right - 14 * dp, r.top + 19 * dp,
                        14 * dp, 0xFFFFFFFF, Paint.Align.CENTER);
            }
        }
        button(c, atkBtn, picked.size() == PICK_COUNT ? "开始攻击" : "还差 "
                + (PICK_COUNT - picked.size()) + " 张", picked.size() == PICK_COUNT
                ? PINK : 0xFF3B6EA5);
    }

    private void drawCardRes(Canvas c) {
        float cx = W / 2f;
        hpBars(c, H * 0.10f);
        text(c, curCard.name, cx, H * 0.35f, W * 0.12f, TYPE_COLOR[curCard.type],
                Paint.Align.CENTER);
        text(c, TYPE_NAME[curCard.type] + " · 敌人" + RESIST_NAME[curCard.type] + " x"
                + RESIST[curCard.type], cx, H * 0.40f, W * 0.04f, 0xCCFFFFFF,
                Paint.Align.CENTER);
        pips(c, cx, H * 0.48f, 10 * dp, lastCoinStates);
        text(c, "造成 " + lastCardDmg, cx, H * 0.60f, W * 0.15f, 0xFFFFFFFF,
                Paint.Align.CENTER);
        text(c, "点击继续", cx, H * 0.72f, W * 0.04f, 0x88FFFFFF, Paint.Align.CENTER);
    }

    private void drawEnemy(Canvas c) {
        float cx = W / 2f;
        hpBars(c, H * 0.10f);
        text(c, "敌人行动", cx, H * 0.38f, W * 0.1f, RED, Paint.Align.CENTER);
        text(c, "你受到 " + enemyDmg + " 点伤害", cx, H * 0.50f, W * 0.07f, 0xFFFFFFFF,
                Paint.Align.CENTER);
        text(c, "本回合 Miss " + turnMiss + " 次,Miss 越多敌人越痛", cx, H * 0.58f,
                W * 0.035f, 0x88FFFFFF, Paint.Align.CENTER);
    }

    private void drawBattleEnd(Canvas c) {
        float cx = W / 2f;
        text(c, win ? "胜 利" : "败 北", cx, H * 0.30f, W * 0.2f,
                win ? C_PERFECT : C_MISS, Paint.Align.CENTER);
        text(c, "共 " + turn + " 回合", cx, H * 0.40f, W * 0.055f, 0xFFFFFFFF,
                Paint.Align.CENTER);
        hpBars(c, H * 0.50f);
        button(c, againBtn, "再战一次", PINK);
        button(c, menuBtn, "返回菜单", CYAN);
    }
}
