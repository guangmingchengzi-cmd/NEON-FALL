HELL ANGELS - 4K 音游 (纯 Java, 无第三方依赖)

用 Code on the Go 打开本文件夹, 运行 assembleDebug 即可得到 APK。
如果 Gradle 同步报版本错误:
  在 Code on the Go 里新建一个 "Empty/No Activity" Java 项目(包名 com.guangcheng.hellangels),
  只把 app/src/main 下的 java、assets、AndroidManifest.xml 覆盖进去即可。

自定义立绘(可选):
  把图片命名为 hero.png (我方) / boss.png (敌方), 放进 app/src/main/assets/ 即可, 不放就显示默认图标。
  - 透明底的抠图: 直接显示在场景里(推荐, 最像参考图)
  - 不透明的图片: 自动裁成带霓虹边框的立绘框, 左上/右上头像也会用它
  - 图片太大会自动缩小, 不用手动处理
